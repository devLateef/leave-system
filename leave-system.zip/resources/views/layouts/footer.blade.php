<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet">
<footer class="main-footer">
    <div class="footer-left">
        Copyright &copy; 2024 <div class="bullet"></div>By <a
            href="https://github.com/devLateef/">devLateef</a>
    </div>
    <div class="footer-right">
        1.0.0
    </div>
</footer>
