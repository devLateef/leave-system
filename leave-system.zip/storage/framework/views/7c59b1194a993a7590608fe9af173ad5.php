
<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
<section class="section">
    <div class="container mt-5">
        <div class="row">
            <div class="col-12 col-sm-10 offset-sm-1 col-md-8 offset-md-2 col-lg-8 offset-lg-2 col-xl-8 offset-xl-2">
                <div class="card card-primary mt-4">
                    <div class="card-header">
                        <h4>Assign HOD Role</h4>
                    </div>

                    <div class="card-body">
                        <form id="hodForm" method="POST" action="<?php echo e(route('profile.assign-admin')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="form-group col-12">
                                    <label for="department">Select Department:</label>
                                    <select id="department" name="department" class="form-control selectric" required>
                                        <option value="">Select Option</option>
                                        <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($department->department); ?>"><?php echo e($department->department); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-12">
                                    <label for="user">Staff List:</label>
                                    <select id="user" name="user_id" class="form-control selectric" required>
                                        <option value="">Select Option</option>
                                    </select>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-12">
                                    <label for="hod">Make Admin</label>
                                    <select id="hod" name="role_id" class="form-control selectric" required>
                                        <option value="">Choose Option</option>
                                        <option value="3">YES</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-primary btn-lg btn-block">
                                    Submit
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="simple-footer">
                    Copyright &copy; Lateef 2024
                </div>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <script>
        $(document).ready(function() {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            $('#department').on('change', function() {
                var department = this.value;
                $('#user').html('<option value="">Select Staff</option>');
                if (department) {
                    $.ajax({
                        url: '/profile/users/' + department,
                        type: 'GET',
                        dataType: 'json',
                        success: function(data) {
                            $.each(data, function(key, value) {
                                $('#user').append('<option value="'+ value.id +'">'+ value.first_name + ' ' + value.last_name +'</option>');
                                // console.log(value)
                            });
                             // Refresh the selectric dropdown
                             $('#user').selectric('refresh');
                        },
                        error: function(xhr, status, error) {
                            console.log(xhr.responseText)
                        }
                    });
                }
            });
        });

        document.getElementById('hodForm').addEventListener('submit', function(event) {
        var userType = document.getElementById('hod').value;
        if (userType == "") {
            alert('Please select a valid option.');
            event.preventDefault(); // Prevent form submission
        }
    });
    </script>    
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\leave-system\resources\views/assign-admin.blade.php ENDPATH**/ ?>