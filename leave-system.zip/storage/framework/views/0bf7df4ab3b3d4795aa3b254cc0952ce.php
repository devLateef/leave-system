

<?php $__env->startSection('content'); ?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet">
<div id="app">
    <style>
        /* Add your print-specific styles here */
        @media print {
            .print-btn, .navbar-bg, .back, .main-sidebar, .section-header-breadcrumb {
                display: none;
            }
            .section-header, .section-body, .card-body {
                margin: 0;
                padding: 0;
                width: 100%;
            }
            .main-wrapper {
                padding: 0;
            }
        }
    </style>
    <div class="main-wrapper">
        <div class="navbar-bg"></div>
        <div class="main-sidebar sidebar-style-2">
            <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <section class="section">
                <div class="section-header">
                    <h1>Leave Approval Note</h1>
                    <div class="section-header-breadcrumb">
                        <div class="breadcrumb-item active">
                            <a href="#" onclick="history.back(); return false;" class="back">
                                <h6>Go Back</h6>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="section-body">
                    <div class="row mt-sm-4">
                        <div class="col-12 col-md-12 col-lg-5">
                        </div>
                        <div class="col-12 col-md-12 col-lg-12">
                            <div class="card">
                                <div class="card-body print-content">
                                    <dl>
                                        <div class="d-flex justify-content-between">
                                            <div>
                                                <h4>Approval Confirmation Details</h4>
                                            </div>
                                            <div>
                                                <button class="btn btn-primary print-btn" onclick="window.print()">Print Approval Note</button>
                                            </div>
                                        </div>
                                        <hr/>
                                        <div class="row">
                                            <div class="form-group col-md-6 col-12">
                                                <dt>Full Name</dt>
                                                <dd><?php echo e($leave->user->first_name); ?> <?php echo e($leave->user->last_name); ?></dd>
                                            </div>
                                            <div class="form-group col-md-6 col-12">
                                                <dt>Leave Type</dt>
                                                <dd><?php echo e($leave->leave_type); ?></dd>
                                            </div>
                                        </div>
                                        <hr>
                                        <div class="row">
                                            <?php
                                                $adminComment = null;
                                            ?>
                                            <div class="form-group col-md-6 col-12">
                                                <dt>Start Date</dt>
                                                <?php $__currentLoopData = $leave->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php
                                                        $adminComment = $comment;
                                                    ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($adminComment): ?>
                                                <dd><?php echo e($adminComment->start_date); ?></dd>
                                            </div>
                                            <div class="form-group col-md-6 col-12">
                                                <dt>End Date</dt>
                                                <dd><?php echo e($adminComment->end_date); ?></dd>
                                            </div>
                                        </div>
                                        <hr>
                                        <div class="row">
                                            <div class="form-group col-md-6 col-12">
                                                <dt>Department</dt>
                                                <?php if($leave->user): ?>
                                                <dd><?php echo e($leave->user->department); ?></dd>
                                                <?php else: ?>
                                                <dd>No Department Found</dd>
                                                <?php endif; ?>
                                            </div>
                                            <div class="form-group col-md-6 col-12">
                                                <dt>Days Approved</dt>
                                                <dd><?php echo e($adminComment->days_given); ?></dd>
                                            </div>
                                        </div>
                                        <hr>
                                        <div class="row">
                                            <div class="form-group col-md-6 col-12">
                                                <dt>Status</dt>
                                                <dd class="fw-bold text-left text-white <?php echo e($leave->final_approval == 'Approved' ? 'bg-success w-25 p-1 rounded' : ($leave->final_approval == 'Defered' ? 'bg-warning w-25 p-1 rounded' : ($leave->final_approval == 'Pending' ? 'bg-warning w-25 p-1 rounded' : 'bg-danger w-25 p-1 rounded'))); ?>"><?php echo e($leave->final_approval); ?></dd>
                                            </div>
                                            <div class="form-group col-md-6 col-12">
                                                <dt>Leave Balance:</dt>
                                                <dd><?php echo e($leave->user->leave_balance); ?></dd>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <hr>
                                        <div class="row">
                                            <div class="form-group col-md-12 col-12">
                                                <dt>Admin Comment:</dt>
                                                <dd><?php echo e($adminComment->message); ?></dd>
                                            </div>
                                        </div>
                                    </dl>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\leave-system\resources\views/approval-note.blade.php ENDPATH**/ ?>