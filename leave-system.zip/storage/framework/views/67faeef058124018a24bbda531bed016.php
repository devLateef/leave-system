<?php $__env->startSection('content'); ?>
<div id="app">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <div class="main-wrapper">
        <div class="navbar-bg"></div>
        <div class="main-sidebar sidebar-style-2">
            <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <section class="section">
                <div class="section-header">
                    <h1>Profile</h1>
                    <div class="section-header-breadcrumb">
                        <div class="breadcrumb-item active"><a
                                href="<?php echo e(route('home')); ?>"><h6>Dashboard</h6></></a></div>
                        <div class="breadcrumb-item">Profile</div>
                    </div>
                </div>
                <div class="section-body">
                    <h2 class="section-title">Hi, <?php echo e($user->first_name); ?>!</h2>
                    <p class="section-lead">
                        See information about yourself on this page.
                    </p>

                    <div class="row mt-sm-4">
                        <div class="col-12 col-md-12 col-lg-5">

                        </div>
                        <div class="col-12 col-md-12 col-lg-12">
                            <div class="card">
                                <div class="card-header">
                                    <h4>Profile Details</h4>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="form-group col-md-4 col-12">
                                            <dd>First Name</dd>
                                            <dl><?php echo e($user->first_name); ?></dl>
                                        </div>
                                        <div class="form-group col-md-4 col-12">
                                            <dd>Last Name</dd>
                                            <dl><?php echo e($user->last_name); ?></dl>
                                        </div>
                                        <div class="form-group col-md-4 col-12">
                                            <dd>Staff ID</dd>
                                            <dl><?php echo e($user->staff_id); ?></dl>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="form-group col-md-4 col-12">
                                            <dd>Date of Birth</dd>
                                            <dl><?php echo e($user->dob); ?></dl>
                                        </div>
                                        <div class="form-group col-md-4 col-12">
                                            <dd>Phone</dd>
                                            <dl><?php echo e($user->phone); ?></dl>
                                        </div>
                                        <div class="form-group col-md-4 col-12">
                                            <dd>Department</dd>
                                            <dl><?php echo e($user->department); ?></dl>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="form-group col-md-4 col-12">
                                            <dd>Gender</dd>
                                            <dl><?php echo e($user->gender); ?></dl>
                                        </div>
                                        <div class="form-group col-md-4 col-12">
                                            <dd>City</dd>
                                            <dl><?php echo e($user->city); ?></dl>
                                        </div>
                                        <div class="form-group col-md-4 col-12">
                                            <dd>Country</dd>
                                            <dl><?php echo e($user->country); ?></dl>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="form-group col-md-12 col-12">
                                            <dd>Address</dd>
                                            <dl><?php echo e($user->address); ?></dl>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
        <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\leave-system\resources\views/show-profile.blade.php ENDPATH**/ ?>