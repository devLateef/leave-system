

<?php $__env->startSection('content'); ?>
<div id="app">
    <div class="main-wrapper">
        <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="navbar-bg"></div>
        <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
        <!-- Main Content -->
        <div class="main-content">
            <section class="section">
                <div class="section-header">
                    <h1>All Hods</h1>
                </div>
                
            </section>
            <table class="table table-striped table-hover table-responsive-md">
                <thead class="table-primary">
                    <tr>
                        <th scope="col">S/N</th>
                        <th scope="col">First Name</th>
                        <th scope="col">Last Name</th>
                        <th scope="col">Staff ID</th>
                        <th scope="col">Department</th>
                        <th scope="col">Gender</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(count($hod) > 0): ?>
                    <?php $__currentLoopData = $hods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="clickable" role="button" onclick="window.location='#'">
                        <td scope="row"><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($hod->user->first_name); ?></td>
                        <td><?php echo e($hod->user->last_name); ?></td>
                        <td><?php echo e($hod->user->staff_id); ?></td>
                        <td><?php echo e($hod->department); ?></td>
                        <td><?php echo e($hod->user->gender); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                    <tr scope="row">
                        <td colspan="7">No Record Found</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>         
        </div>
        <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\leave-system\resources\views/all-hod.blade.php ENDPATH**/ ?>