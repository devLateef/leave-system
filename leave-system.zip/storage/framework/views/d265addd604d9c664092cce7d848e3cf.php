

<?php $__env->startSection('content'); ?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet">
<div id="app">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <style>
    .dataTables_wrapper .dataTables_paginate .paginate_button {
        background-color: #2983e9;
        color: white;
        border: none;
        padding: 5px 10px !important;
        margin: 0 4px !important;
        cursor: pointer;
        border-radius: 4px;
    }
    .dataTables_wrapper .dataTables_paginate .paginate_button.current {
    background-color: #0056b3;
    color: white;
    }
    .dataTables_wrapper .dataTables_paginate {
    text-align: center;
    margin-top: 20px !important;
    }
    .dataTables_wrapper .dataTables_paginate .paginate_button:hover {
        background-color: #0056b3;
        color: white;
    }
    /* Style the DataTable search bar */
    .dataTables_filter {
        text-align: left; /* Align the search bar to the left */
        margin-bottom: 15px; /* Add space below the search bar */
    }
    .dataTables_filter label {
    font-weight: bold !important; /* Make the label bold */
    color: #333 !important; /* Change label color */
    }
    .dataTables_filter input {
    width: 300px; /* Set a fixed width */
    padding: 10px; /* Add padding */
    border: 1px solid #ddd; /* Add border */
    border-radius: 10px; /* Round the corners */
    box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1); /* Add subtle shadow */
    outline: none; /* Remove default outline */
    transition: all 0.3s ease; /* Smooth transition */
    }
    .dataTables_filter input:focus {
    border-color: #007BFF; /* Change border color on focus */
    box-shadow: 0px 2px 5px rgba(0, 123, 255, 0.5); /* Change shadow on focus */
    }
    </style>
    <div class="main-wrapper">
        <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="navbar-bg"></div>
        <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
        <!-- Main Content -->
        <div class="main-content">
            <section class="section">
                <div class="section-header">
                    <h1>All Users</h1>
                </div>
                
            </section>
            <table id="usersTable" class="table table-striped table-hover table-responsive-md">
                <thead class="table-primary">
                    <tr>
                        <th scope="col">S/N</th>
                        <th scope="col">First Name</th>
                        <th scope="col">Last Name</th>
                        <th scope="col">Staff ID</th>
                        <th scope="col">Department</th>
                        <th scope="col">Gender</th>
                        <th scope="col">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(count($users) > 0): ?>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="clickable" role="button" onclick="window.location='#'">
                        <td scope="row"><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($user->first_name); ?></td>
                        <td><?php echo e($user->last_name); ?></td>
                        <td><?php echo e($user->staff_id); ?></td>
                        <td><?php echo e($user->department); ?></td>
                        <td><?php echo e($user->gender); ?></td>
                        
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                    <tr scope="row">
                        <td colspan="7">No Record Found</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>         
        </div>
        <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<script>
    $(document).ready(function () {
    $('#usersTable').dataTable({
        "serverSide": true,
        "responsive": true,
        "ajax": "<?php echo e(route('profile.users')); ?>",
        columns: [
            { data: null, name: 'sn' },
            { data: 'first_name', name: 'first_name' },
            { data: 'last_name', name: 'last_name' },
            { data: 'staff_id', name: 'staff_id' },
            { data: 'department', name: 'department' },
            { data: 'gender', name: 'gender' },
            {
                render: function(data, type, row) {
                // Construct the URL with the user ID dynamically
                var url = '<?php echo e(route("profile.user-detail", ":id")); ?>';
                url = url.replace(':id', row.id);
                
                return '<td><a href="' + url + '"><button class="btn btn-primary m-1">Show</button></a></td>';
                },
                orderable: false,
                searchable: false
            }
        ],
        createdRow: function (row, data, index) {
                    // Add serial number
                    $('td', row).eq(0).html(index + 1 + this.api().page.info().start);
                    }
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\leave-system\resources\views/all-users.blade.php ENDPATH**/ ?>