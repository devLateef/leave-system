

<?php $__env->startSection('content'); ?>
<div id="app">
    <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="main-wrapper">
        <div class="navbar-bg"></div>
        <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
        <!-- Main Content -->
        <div class="main-content">
            <section class="section">
                <div class="section-header">
                    <h1>Deferred Applications</h1>
                </div>
            </section>

            <?php if($user->role_id == $superAdmin): ?>
            <!-- Admin view: Show all deferred leave applications -->
            <table class="table table-striped table-hover">
                <thead class="table-primary">
                    <tr>
                        <th scope="col">S/N</th>
                        <th>Full Name</th>
                        <th scope="col">Leave Type</th>
                        <th scope="col">Expected Start Date</th>
                        <th scope="col">Expected End Date</th>
                        <th scope="col">HOD Approval</th>
                        <th scope="col">Final Approval</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(count($leave_applications) > 0): ?>
                        <?php $__currentLoopData = $leave_applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leave): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($leave->final_approval == 'Defered'): ?>
                                <tr>
                                    <td scope="row"><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($leave->user->first_name ." ". $leave->user->last_name); ?></td>
                                    <td><?php echo e($leave->leave_type); ?></td>
                                    <td><?php echo e($leave->start_date); ?></td>
                                    <td><?php echo e($leave->end_date); ?></td>
                                    <td class="fw-bold <?php echo e($leave->hod_approval == 'Approved' ? 'text-success' : ($leave->hod_approval == 'Defered' ? 'text-info' : ($leave->hod_approval == 'Pending' ? 'text-warning' : 'text-danger'))); ?>"><?php echo e($leave->hod_approval); ?></td>
                                    <td class="fw-bold <?php echo e($leave->final_approval == 'Approved' ? 'text-success' : ($leave->final_approval == 'Defered' ? 'text-info' : ($leave->final_approval == 'Pending' ? 'text-warning' : 'text-danger'))); ?>"><?php echo e($leave->final_approval); ?></td>
                                </tr>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <tr scope="row">
                            <td colspan="6">No Record Found</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
            <?php elseif($user->role_id == $admin): ?>
            <table class="table table-striped table-hover">
                <thead class="table-primary">
                    <tr>
                        <th scope="col">S/N</th>
                        <th>Full Name</th>
                        <th scope="col">Leave Type</th>
                        <th scope="col">Expected Start Date</th>
                        <th scope="col">Expected End Date</th>
                        <th scope="col">HOD Approval</th>
                        <th scope="col">Final Approval</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(count($leave_applications) > 0): ?>
                        <?php $__currentLoopData = $leave_applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leave): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($leave->final_approval == 'Defered' && $leave->user->role_id != 4): ?>
                                <tr>
                                    <td scope="row"><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($leave->user->first_name ." ". $leave->user->last_name); ?></td>
                                    <td><?php echo e($leave->leave_type); ?></td>
                                    <td><?php echo e($leave->start_date); ?></td>
                                    <td><?php echo e($leave->end_date); ?></td>
                                    <td class="fw-bold <?php echo e($leave->hod_approval == 'Approved' ? 'text-success' : ($leave->hod_approval == 'Defered' ? 'text-info' : ($leave->hod_approval == 'Pending' ? 'text-warning' : 'text-danger'))); ?>"><?php echo e($leave->hod_approval); ?></td>
                                    <td class="fw-bold <?php echo e($leave->final_approval == 'Approved' ? 'text-success' : ($leave->final_approval == 'Defered' ? 'text-info' : ($leave->final_approval == 'Pending' ? 'text-warning' : 'text-danger'))); ?>"><?php echo e($leave->final_approval); ?></td>
                                </tr>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <tr scope="row">
                            <td colspan="6">No Record Found</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
            <?php elseif($user->role_id == $hod): ?>
            <!-- HOD view: Show deferred leave applications of users in the same department -->
            <table class="table table-striped table-hover">
                <thead class="table-primary">
                    <tr>
                        <th scope="col">S/N</th>
                        <th>Full Name</th>
                        <th scope="col">Leave Type</th>
                        <th scope="col">Expected Start Date</th>
                        <th scope="col">Expected End Date</th>
                        <th scope="col">HOD Approval</th>
                        <th scope="col">Final Approval</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(count($leave_applications) > 0): ?>
                        <?php $__currentLoopData = $leave_applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leave): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($leave->user->department == $user->department): ?>
                                <?php if($leave->user->department == $user->department && $leave->final_approval == 'Approved'): ?>
                                    <tr>
                                        <td scope="row"><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($leave->user->first_name ." ". $leave->user->last_name); ?></td>
                                        <td><?php echo e($leave->leave_type); ?></td>
                                        <td><?php echo e($leave->start_date); ?></td>
                                        <td><?php echo e($leave->end_date); ?></td>
                                        <td class="fw-bold <?php echo e($leave->hod_approval == 'Approved' ? 'text-success' : ($leave->hod_approval == 'Defered' ? 'text-info' : ($leave->hod_approval == 'Pending' ? 'text-warning' : 'text-danger'))); ?>"><?php echo e($leave->hod_approval); ?></td>
                                        <td class="fw-bold <?php echo e($leave->final_approval == 'Approved' ? 'text-success' : ($leave->final_approval == 'Defered' ? 'text-info' : ($leave->final_approval == 'Pending' ? 'text-warning' : 'text-danger'))); ?>"><?php echo e($leave->final_approval); ?></td>
                                    </tr>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <tr scope="row">
                            <td colspan="6">No Record Found</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
            <?php else: ?>
            <!-- User view: Show only user's own deferred leave applications -->
            <table class="table table-striped table-hover">
                <thead class="table-primary">
                    <tr>
                        <th scope="col">S/N</th>
                        <th>Full Name</th>
                        <th scope="col">Leave Type</th>
                        <th scope="col">Expected Start Date</th>
                        <th scope="col">Expected End Date</th>
                        <th scope="col">HOD Approval</th>
                        <th scope="col">Final Approval</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(count($leave_applications) > 0): ?>
                        <?php $__currentLoopData = $leave_applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leave): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($leave->user_id == $user->id): ?>
                                <?php if($leave->final_approval == 'Defered'): ?>
                                    <tr>
                                        <td scope="row"><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($leave->user->first_name ." ". $leave->user->last_name); ?></td>
                                        <td><?php echo e($leave->leave_type); ?></td>
                                        <td><?php echo e($leave->start_date); ?></td>
                                        <td><?php echo e($leave->end_date); ?></td>
                                        <td class="fw-bold <?php echo e($leave->hod_approval == 'Approved' ? 'text-success' : ($leave->hod_approval == 'Defered' ? 'text-info' : ($leave->hod_approval == 'Pending' ? 'text-warning' : 'text-danger'))); ?>"><?php echo e($leave->hod_approval); ?></td>
                                        <td class="fw-bold <?php echo e($leave->final_approval == 'Approved' ? 'text-success' : ($leave->final_approval == 'Defered' ? 'text-info' : ($leave->final_approval == 'Pending' ? 'text-warning' : 'text-danger'))); ?>"><?php echo e($leave->final_approval); ?></td>
                                    </tr>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <tr scope="row">
                            <td colspan="7">No Record Found</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>
        <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\leave-system\resources\views/defer-leave.blade.php ENDPATH**/ ?>