<?php
return [
    'SUPER_ADMIN' => env('SUPER_ADMIN'),
    'ADMIN' => env('ADMIN'),
    'HOD' => env('HOD'),
];