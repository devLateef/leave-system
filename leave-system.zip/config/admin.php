<?php

return [
    'FIRST_NAME' => env('SUPER_FIRST_NAME'),
    'LAST_NAME' => env('SUPER_LAST_NAME'),
    'STAFFID' => env('SUPER_STAFFID'),
    'DEPARTMENT' => env('SUPER_DEPARTMENT'),
    'EMAIL' => env('SUPER_EMAIL'),
    'DOB' => env('SUPER_DOB'),
    'CITY' => env('SUPER_CITY'),
    'COUNTRY' => env('SUPER_CITY'),
    'ADDRESS' => env('SUPER_ADDRESS'),
    'PHONE' => env('SUPER_PHONE'),
    'GENDER' => env('SUPER_GENDER'),
    'PASSWORD' =>env('SUPER_PASSWORD'),
    'ROLEID' => env('SUPER_ADMIN'),
    'DEFAULT' => env('DEFAULT'),
];